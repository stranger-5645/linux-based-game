Challenge 2: Rebuild the system using mkdir and touch!
