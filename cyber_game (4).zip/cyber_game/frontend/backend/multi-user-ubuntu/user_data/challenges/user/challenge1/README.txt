Welcome to Challenge 1! Use 'ls', 'cd', 'pwd' to explore.
